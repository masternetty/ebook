
function abrirModal(id) {
    document.getElementById('modal' + id).style.display = 'flex';
}
function fecharModal(id) {
    document.getElementById('modal' + id).style.display = 'none';
}
